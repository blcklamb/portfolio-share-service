import React, { useEffect, useCallback, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { Container, Col, Row, Form, Button } from "react-bootstrap";
import { useAlert } from "react-alert";

import * as Api from "../../api";
import { DispatchContext } from "../../App";
import CreditForm from "./CreditForm"
import { GoogleLogin } from "react-google-login";

function LoginForm() {
  const navigate = useNavigate();
  const dispatch = useContext(DispatchContext);

  // useState로 email 상태를 생성함.
  const [email, setEmail] = useState("");
  // useState로 password 상태를 생성함.
  const [password, setPassword] = useState("");
  // useAlert로 alert 함수 이용함.
  const alert = useAlert()

  // 이메일이 abc@example.com 형태인지 regex를 이용해 확인함.
  const validateEmail = (email) => {
    return email
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
  };

  // 위 validateEmail 함수를 통해 이메일 형태 적합 여부를 확인함.
  const isEmailValid = validateEmail(email);
  // 비밀번호가 4글자 이상인지 여부를 확인함.
  const isPasswordValid = password.length >= 4;
  // 이메일과 비밀번호 조건이 동시에 만족되는지 확인함.
  const isFormValid = isEmailValid && isPasswordValid;
  
  // 이메일로 받은 링크로 접속 시 로그인 알림
  const alertLoginValidated = useCallback(async () => {
    let a = window.location.search.split('?');
    if (a.length === 1 && a[0]==="") return {};
    else if (a[1]==="validation=true") {
      alert.info("이메일 인증이 완료되었습니다.")
      alert.info("로그인 해주세요.")
    }
  }, [])

  useEffect(()=>{
    alertLoginValidated();
  }, [alertLoginValidated])

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // "user/login" 엔드포인트로 post요청함.
      const res = await Api.post("user/login", {
        email,
        password,
      });
      // 유저 정보는 response의 data임.
      const user = res.data;
      // JWT 토큰은 유저 정보의 token임.
      const jwtToken = user.token;
      // sessionStorage에 "userToken"이라는 키로 JWT 토큰을 저장함.
      sessionStorage.setItem("userToken", jwtToken);
      // dispatch 함수를 이용해 로그인 성공 상태로 만듦.
      dispatch({
        type: "LOGIN_SUCCESS",
        payload: user,
      });

      alert.success('로그인 성공하였습니다.')
      // 기본 페이지로 이동함.
      navigate("/", { replace: true });

    } catch (err) {
      if (err.response.data==='"해당 이메일은 가입 내역이 없습니다. 다시 한 번 확인해 주세요."') {
        alert.error('해당 이메일은 가입 내역이 없습니다.');
        alert.error('다시 한 번 확인해 주세요.');
      } else if (err.response.data==='"비밀번호가 일치하지 않습니다. 다시 한 번 확인해 주세요."') {
        alert.error('비밀번호가 일치하지 않습니다.')
        alert.error('다시 한 번 확인해 주세요.')
      } else if (err.response.data==='"이메일 인증이 필요합니다. 이메일 보관함을 확인해주세요."') {
        alert.error('이메일 인증이 필요합니다.')
        alert.error('이메일 보관함을 확인해주세요.')
      }
    }
  };

  const handleFailure = async (result) => {

  };

  const handleLogin = async (googleData) => {
    try {
      const user = await Api.post("login/google", {
        token: googleData.tokenId,
      })
        .then((res) => { return res.data; });
      // JWT 토큰은 유저 정보의 token임.
      const jwtToken = user.token;
      // sessionStorage에 "userToken"이라는 키로 JWT 토큰을 저장함.
      sessionStorage.setItem("userToken", jwtToken);
      // dispatch 함수를 이용해 로그인 성공 상태로 만듦.
      dispatch({
        type: "LOGIN_SUCCESS",
        payload: user,
      });

      // 기본 페이지로 이동함.
      navigate("/", { replace: true });
    } catch (err) {
      console.log("로그인에 실패하였습니다.\n", err);
    }
  };

  return (
    <Container>
      <Row className="justify-content-md-center mt-5">
        <Col lg={8}>
          <Row>
          <CreditForm/>
          </Row>
          <Form onSubmit={handleSubmit}>
            <h4>소셜 로그인</h4>
            <hr></hr>
            <Row className="mb-5 text-center">
              <Col>
              <GoogleLogin
                clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}
                buttonText="구글로 로그인하기"
                onSuccess={handleLogin}
                onFailure={handleFailure}
                cookiePolicy={"single_host_origin"}
              />
              </Col>
              <Col>
              <Button
                    variant="secondary"
                    type="submit"
                    disabled={!isFormValid}
                  >
                    깃허브로 로그인하기
                  </Button>
                  </Col>
            </Row>
            <h4>이메일 로그인</h4>
            <hr></hr>
            <Row>
              <Form.Group controlId="loginEmail">
                <Form.Label>이메일 주소</Form.Label>
                <Form.Control
                  type="email"
                  autoComplete="on"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                {!isEmailValid && (
                  <Form.Text className="text-success">
                    이메일 형식이 올바르지 않습니다.
                  </Form.Text>
                )}
              </Form.Group>

              <Form.Group controlId="loginPassword" className="mt-3">
                <Form.Label>비밀번호</Form.Label>
                <Form.Control
                  type="password"
                  autoComplete="on"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                {!isPasswordValid && (
                  <Form.Text className="text-success">
                    비밀번호는 4글자 이상입니다.
                  </Form.Text>
                )}
              </Form.Group>
            </Row>
            <Row>
              <Col>
                <Form.Group as={Row} className="m-3 text-center">
                  <Button
                    variant="primary"
                    type="submit"
                    disabled={!isFormValid}
                  >
                    로그인
                  </Button>
                </Form.Group>
              </Col>
              <Col>
                <Form.Group as={Row} className="m-3 text-center">
                  <Button variant="light" onClick={() => navigate("/register")}>
                    회원가입하기
                  </Button>
                </Form.Group>
              </Col>
            </Row>

            <Form.Group as={Row} className="mt-3 text-center">
              <Col sm={{ span: 20 }}>
                <Button
                  variant="secondary"
                  onClick={() => navigate("/reset-password")}
                >
                  비밀번호 변경하기
                </Button>
              </Col>
            </Form.Group>


          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default LoginForm;
