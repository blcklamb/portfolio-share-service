import React, { useState } from 'react';
import { Button, Offcanvas } from 'react-bootstrap';

const OffCanvasExample=({ ...props })=> {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
    <h1>안녕하세요</h1>
      <div onClick={handleShow} className="me-2">
        <h2>이상한 나라의 개발자들 입니다.</h2>
      </div>
      <Offcanvas show={show} onHide={handleClose} {...props}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Offcanvas</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          Some text as placeholder. In real life you can have the elements you
          have chosen. Like, text, images, lists, etc.
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

const CreditForm = () => {
  return (
        <OffCanvasExample  placement={'end'}  />
  );
}

export default CreditForm;